#ifndef FUNCTION_H
#define FUNCTION_H

#include <math.h>

float f_x(float x);
float g_x(float x);

#endif
