#ifndef FUNCTION_H
#define FUNCTION_H
#include <math.h>

void discriminant(int a, int b, int c);
void two_solutions(int a, int b, int c, int D);
void one_solution(int a, int b);
void print_equation(int a, int b, int c);


#endif
