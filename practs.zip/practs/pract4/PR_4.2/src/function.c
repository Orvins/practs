#ifndef FUNCTION_C
#define FUNCTION_C
#include <math.h>
#include <stdio.h>


void help() {
	printf("  \n ========================================");
	printf("  \n|  -h - Help on using the program        |");
	printf("  \n|  -o - Create a file of the given name  |");
	printf("  \n|  -c - Special mode of operation        |");
	printf("  \n ========================================");

}

#endif
