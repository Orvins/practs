#ifndef FUNCTION_H
#define FUNCTION_H

#include <math.h>


int balance (int credits);
int combinations(int a, int b, int c, int pull, int dp);
void possible_win ();

#endif
