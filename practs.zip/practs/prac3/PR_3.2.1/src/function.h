#ifndef FUNCTION_H
#define FUNCTION_H
#include <math.h>

void print(float *x, int size);
void filling(float *x, int size);
void z_1(float *x, int size);
void z_2(float *x, int size);

#endif
