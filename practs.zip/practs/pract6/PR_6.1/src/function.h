#ifndef FUNCTION_H
#define FUNCTION_H
#include <math.h>

void help();
void all();

#endif
