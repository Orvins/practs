#ifndef FUNCTION_H
#define FUNCTION_H
#include <math.h>

int my_system(const char *cmd_string);

#endif
